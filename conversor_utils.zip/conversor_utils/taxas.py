"""Taxas de câmbio simuladas (estáticas)"""

taxas = {
    "EUR": 1.0,
    "USD": 1.08,
    "GBP": 0.85
}