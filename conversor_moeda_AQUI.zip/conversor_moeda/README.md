# Conversor de Moeda em Python 

Este é um projeto que permite converter valores entre três moedas: **EUR**, **USD** e **GBP**.

## Estrutura do Projeto


## Como correr o projeto

1. Abrir um terminal
2. Vai até à pasta do projeto
```bash 
cd conversor_moeda
```
3. Instalar o Streamlit (caso ainda não o tenhas)
```bash 
pip install streamlit
```
4. Executar a aplicação: 
```bash 
streamlit run app.py
```

A aplicação será automaticamente aberta no browser

## Dependências

Instalação do streamlit

## Próximos passos (Parte 2)

- Utilizar uma API real para obter as taxas de câmbio atualizadas
- Adicionar mais moedas